import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;
//Name-->
/*
algorithm help� 
The determineWinner method goes through the matrix to find a winner.
It checks for a horizontal winner first. 
Then, it checks for a vertical winner. 
Lastly, it checks for a diagonal winner.� 
It must also check for a draw. 
A draw occurs if neither player wins.
 You will read in each game from a file and store each game in a matrix.
  The file will have multiple games in it.
*/
public class Main
{
	public static void main( String args[] ) throws IOException
	{

	}
}